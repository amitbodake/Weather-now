// src/App.js
import React, { useState } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import WeatherDisplay from './components/WeatherDisplay';
import { fetchCoordinates } from './api/geocodeAPI';
import { fetchWeatherData } from './api/weatherAPI';
import './App.css';

const App = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState('');
  const [cityName, setCityName] = useState(''); // New state for city name
  const getWeather = async (city) => {
    try {
      setError(''); // Reset error message
      setWeatherData(null); // Reset weather data on new search
      setCityName('');
      if (!city.trim()) {
        setError('Please enter a city name.');
        return;
      }

      // Fetch coordinates
      const { latitude, longitude } = await fetchCoordinates(city);

      if (!latitude || !longitude) {
        setError("Couldn't find the specified city. Please try another one.");
        return;
      }

      // Fetch weather data
      const weather = await fetchWeatherData(latitude, longitude);
      setWeatherData(weather);
      setCityName(city);
    } catch (err) {
      if (err.message.includes('Unable to find coordinates')) {
        setError(
          "Couldn't find the specified city. Please enter a valid city name."
        );
      } else if (err.message.includes('Network Error')) {
        setError(
          'Network error. Please check your internet connection and try again.'
        );
      } else {
        setError('An unexpected error occurred. Please try again later.');
      }
    }
  };

  return (
    <div className="App">
      <Header />
      <SearchBar onSearch={getWeather} />
      <WeatherDisplay
        weatherData={weatherData}
        cityName={cityName}
        error={error}
      />
    </div>
  );
};

export default App;
