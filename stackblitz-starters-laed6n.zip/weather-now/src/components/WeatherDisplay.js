// src/components/WeatherDisplay.js
import React from 'react';
import { weatherConditions } from '../weatherConditions';

const WeatherDisplay = ({ weatherData, cityName, error }) => {
  if (error) return <p>{error}</p>;
  if (!weatherData) return null;

  const { city, temperature, weathercode, windspeed } = weatherData;
  const condition = weatherConditions[weathercode] || 'Unknown condition';

  return (
    <div>
      <h2>Current Weather in {cityName}</h2>
      <p>Temperature: {temperature} °C</p>
      <p>Condition: {condition}</p>
      <p>Wind Speed: {windspeed} km/h</p>
    </div>
  );
};

export default WeatherDisplay;
