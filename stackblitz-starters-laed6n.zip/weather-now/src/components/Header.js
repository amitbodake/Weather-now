// src/components/Header.js
import React from 'react';

const Header = () => (
  <header>
    <h1>Weather Now</h1>
  </header>
);

export default Header;
