// src/api/geocodeApi.js
import axios from 'axios';

export const fetchCoordinates = async (city) => {
  try {
    const geocodeApiKey = process.env.REACT_APP_GEOCODE_API_KEY;
    const response = await axios.get(`https://api.opencagedata.com/geocode/v1/json`, {
      params: {
        q: city,
        key: geocodeApiKey,
      },
    });
    const { lat, lng } = response.data.results[0].geometry;
    return { latitude: lat, longitude: lng };
  } catch (error) {
    throw new Error('Unable to find coordinates for the city.');
  }
};
